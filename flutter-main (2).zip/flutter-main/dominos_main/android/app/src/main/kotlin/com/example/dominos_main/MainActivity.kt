package com.example.dominos_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
